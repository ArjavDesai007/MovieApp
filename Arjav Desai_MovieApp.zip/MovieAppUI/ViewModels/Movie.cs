﻿using System.Collections.Generic;
using System.ComponentModel;

namespace MovieAppUI.ViewModels
{
    public class Movie : INotifyPropertyChanged
    {
        private string posterImage;

        public string MovieName { get; set; }
        public List<string> MovieCast { get; set; }
        public string MovieDetails { get; set; }

        public string PosterImage
        {
            get { return posterImage; }
            set
            {
                posterImage = value;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
