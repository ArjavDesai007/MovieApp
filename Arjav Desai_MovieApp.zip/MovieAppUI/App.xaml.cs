﻿using System;
using DLToolkit.Forms.Controls;
using MovieAppUI.Views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MovieAppUI
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            FlowListView.Init();

            MainPage = new Login();
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
