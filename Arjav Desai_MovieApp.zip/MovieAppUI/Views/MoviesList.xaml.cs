﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using MovieAppUI.ViewModels;
using Xamarin.Forms;

namespace MovieAppUI.Views
{
    public partial class MoviesList : ContentPage
    {
        List<string> castList;
        string movieDetails = string.Empty, movieName = string.Empty;
        public ObservableCollection<Movie> moviesList;

        public MoviesList()
        {
            InitializeComponent();

            //BindingContext = this;

            castList = new List<string>() { "Robert Downey Jr.", "Chris Hemsworth", "Mark Ruffalo", "Chris Evans", "Scarlett Johansson" };
            movieDetails = "The Avengers and their allies must be willing to sacrifice all in an attempt to defeat the powerful Thanos before his blitz of devastation and ruin puts an end to the universe.﻿ Now that Earth has put its mark on the universe through the Avengers, all superheroes, including ones from other parts of the Galaxy, must join forces to stop the powerful Thanos from taking all the infinity stones and destroying the universe one planet at a time";
            movieName = "Avengers";
            moviesList = new ObservableCollection<Movie>();

            //GetData();
        }

        void ShowMovieDetails(System.Object sender, System.EventArgs e)
        {
            Movie movie = new Movie()
            {
                MovieCast = castList,
                MovieDetails = movieDetails,
                MovieName = movieName,
                PosterImage = "poster4"
            };

            Navigation.PushAsync(new MoviesDetails(movie));
        }
        //void GetData()
        //{
        //    try
        //    {
        //        for (int i = 0; i <= 6; i++)
        //        {
        //            Movie movie = new Movie()
        //            {
        //                MovieCast = castList,
        //                MovieDetails = movieDetails,
        //                MovieName = movieName,
        //                PosterImage = "poster4"
        //            };

        //            moviesList.Add(movie);
        //        }

        //        MoviesListView.ItemsSource = moviesList;
        //    }
        //    catch (Exception ex)
        //    {
        //        Debug.WriteLine(ex.Message);
        //    }
        //}

        //void ShowMovieDetails(System.Object sender, Xamarin.Forms.ItemTappedEventArgs e)
        //{
        //    if (e.Item != null)
        //        Navigation.PushAsync(new MoviesDetails(e.Item as Movie));
        //}
    }
}
