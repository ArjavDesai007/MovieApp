﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MovieAppUI.Views
{
    public partial class Login : ContentPage
    {
        public Login()
        {
            InitializeComponent();
        }

        void SignInClicked(System.Object sender, System.EventArgs e)
        {
            App.Current.MainPage = new NavigationPage(new MoviesList());
        }
    }
}
