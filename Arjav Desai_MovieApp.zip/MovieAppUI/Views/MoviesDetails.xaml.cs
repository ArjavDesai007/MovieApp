﻿using System.Collections.Generic;
using MovieAppUI.ViewModels;
using Xamarin.Forms;

namespace MovieAppUI.Views
{
    public partial class MoviesDetails : ContentPage
    {
        public MoviesDetails(Movie movie)
        {
            InitializeComponent();

            Title = movie.MovieName;

            foreach (var cast in movie.MovieCast)
            {
                lbl_MovieCast.Text += $"{cast}, ";
            }

            lbl_MovieDescription.Text = movie.MovieDetails;
            img_MoviePoster.Source = movie.PosterImage;
        }
    }
}
